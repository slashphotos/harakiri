#pragma once

bool l3g4200dDetect(sensor_t * gyro);
void l3g4200dConfig(uint16_t lpf);
